-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 23-01-2014 a las 23:39:44
-- Versión del servidor: 5.1.44
-- Versión de PHP: 5.3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `web_spiderframe`
--

CREATE DATABASE IF NOT EXISTS `web_spiderframe`;
USE `web_spiderframe`;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_address`
--

CREATE TABLE `cat_address` (
  `cat_address_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_address_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=6 ;

--
-- Volcar la base de datos para la tabla `cat_address`
--

INSERT INTO `cat_address` VALUES(1, 'Personal', '1');
INSERT INTO `cat_address` VALUES(2, 'Card', '1');
INSERT INTO `cat_address` VALUES(3, 'Shipping', '1');
INSERT INTO `cat_address` VALUES(4, 'Provider', '1');
INSERT INTO `cat_address` VALUES(5, 'Other', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_card`
--

CREATE TABLE `cat_card` (
  `cat_card_id` int(11) NOT NULL AUTO_INCREMENT,
  `card` varchar(45) CHARACTER SET ucs2 COLLATE ucs2_bin NOT NULL,
  PRIMARY KEY (`cat_card_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `cat_card`
--

INSERT INTO `cat_card` VALUES(1, 'Visa');
INSERT INTO `cat_card` VALUES(2, 'Master Card');
INSERT INTO `cat_card` VALUES(3, 'American Express');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_contact`
--

CREATE TABLE `cat_contact` (
  `cat_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `contact` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`cat_contact_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2147483647 ;

--
-- Volcar la base de datos para la tabla `cat_contact`
--

INSERT INTO `cat_contact` VALUES(1, 'mail');
INSERT INTO `cat_contact` VALUES(2, 'phone');
INSERT INTO `cat_contact` VALUES(3, 'cell');
INSERT INTO `cat_contact` VALUES(4, 'fax');
INSERT INTO `cat_contact` VALUES(5, 'phone work');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_date_format`
--

CREATE TABLE `cat_date_format` (
  `cat_date_format_id` int(11) NOT NULL AUTO_INCREMENT,
  `date_format` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_date_format_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2147483647 ;

--
-- Volcar la base de datos para la tabla `cat_date_format`
--

INSERT INTO `cat_date_format` VALUES(1, 'DDMMYYYY', '1');
INSERT INTO `cat_date_format` VALUES(2, 'MMDDYYYY', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_image`
--

CREATE TABLE `cat_image` (
  `cat_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `context` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_image_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

--
-- Volcar la base de datos para la tabla `cat_image`
--

INSERT INTO `cat_image` VALUES(1, 'user', 'Image for users', '1');
INSERT INTO `cat_image` VALUES(2, 'article', 'Image for articles', '1');
INSERT INTO `cat_image` VALUES(3, 'galery', 'General images for galery', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_mail_controller`
--

CREATE TABLE `cat_mail_controller` (
  `cat_mail_controller_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `user` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `server` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'smt.gmail.com',
  `domain` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'gmail.com',
  `password` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT '50',
  `port` int(11) NOT NULL DEFAULT '465',
  `ssl` enum('true','false') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'true',
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_mail_controller_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `cat_mail_controller`
--

INSERT INTO `cat_mail_controller` VALUES(1, 'Support', 'test.estilosfrescos', 'smtp.gmail.com', 'gmail.com', 'spidermay_test', 50, 465, 'true', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_module`
--

CREATE TABLE `cat_module` (
  `cat_module_id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `module_context` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  KEY `modulo_id` (`cat_module_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=16 ;

--
-- Volcar la base de datos para la tabla `cat_module`
--

INSERT INTO `cat_module` VALUES(1, 'admin', 'Admin', 'Administración general del sistema', '1');
INSERT INTO `cat_module` VALUES(2, 'user', 'User', 'Control de usuarios', '1');
INSERT INTO `cat_module` VALUES(3, 'address', 'Address', 'Control address for users', '1');
INSERT INTO `cat_module` VALUES(4, 'message', 'Messages', '', '1');
INSERT INTO `cat_module` VALUES(5, 'permission', 'Permission', '', '1');
INSERT INTO `cat_module` VALUES(6, 'city', 'Cities', '', '1');
INSERT INTO `cat_module` VALUES(7, 'mail', 'Mailer', '', '1');
INSERT INTO `cat_module` VALUES(8, 'images', 'Admin images', '', '1');
INSERT INTO `cat_module` VALUES(9, 'state', 'States', '', '1');
INSERT INTO `cat_module` VALUES(10, 'dictionary', 'Dictionaries', 'All reference to add and edit dictionaries', '1');
INSERT INTO `cat_module` VALUES(11, 'reference', 'Reference', '', '1');
INSERT INTO `cat_module` VALUES(12, 'stock', 'Stock', 'Admin Stocks', '1');
INSERT INTO `cat_module` VALUES(13, 'provider', 'Provider', '', '1');
INSERT INTO `cat_module` VALUES(14, 'settings', 'Settings', 'Settings for user', '1');
INSERT INTO `cat_module` VALUES(15, 'products', 'Products', 'Admin every products', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_module_permission`
--

CREATE TABLE `cat_module_permission` (
  `cat_module_permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_module_id` int(11) NOT NULL,
  `permission` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `permission_context` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_module_permission_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=42 ;

--
-- Volcar la base de datos para la tabla `cat_module_permission`
--

INSERT INTO `cat_module_permission` VALUES(1, 2, 'add_user', 'Add user', 'Agregar nuevos usuarios', '0');
INSERT INTO `cat_module_permission` VALUES(2, 2, 'edit_user', 'Edit user', 'Editar usuarios', '1');
INSERT INTO `cat_module_permission` VALUES(3, 2, 'inactive_user', 'Inactive user', 'Desactivar usuarios', '1');
INSERT INTO `cat_module_permission` VALUES(4, 2, 'delete_user', 'Delete user', 'Delete users', '1');
INSERT INTO `cat_module_permission` VALUES(5, 2, 'view_user', 'View user', 'Ver usuarios', '1');
INSERT INTO `cat_module_permission` VALUES(6, 2, 'list_user', 'List user', 'Listing users', '1');
INSERT INTO `cat_module_permission` VALUES(7, 2, 'view_permission', 'View permission', 'View permissions by user', '1');
INSERT INTO `cat_module_permission` VALUES(8, 5, 'inactive_module_permission', '', '0', '1');
INSERT INTO `cat_module_permission` VALUES(9, 3, 'add_address', 'Add address', 'Agregar permisos', '1');
INSERT INTO `cat_module_permission` VALUES(10, 3, 'edit_address', 'Edit address', '', '1');
INSERT INTO `cat_module_permission` VALUES(11, 6, 'add_city', '', '0', '1');
INSERT INTO `cat_module_permission` VALUES(12, 6, 'edit_city', '', '0', '1');
INSERT INTO `cat_module_permission` VALUES(13, 8, 'add_image', 'Add image', 'Add imagen for users', '1');
INSERT INTO `cat_module_permission` VALUES(14, 2, 'add_permission', 'Add permission', 'Add permissions by user', '1');
INSERT INTO `cat_module_permission` VALUES(15, 3, 'dele_address', 'Dele Address', '', '1');
INSERT INTO `cat_module_permission` VALUES(16, 3, 'delete_address', 'Delete Address', '', '1');
INSERT INTO `cat_module_permission` VALUES(17, 5, 'add_module', 'Add module', 'Add module permissions', '1');
INSERT INTO `cat_module_permission` VALUES(18, 10, 'add_dictionary', 'Add dictionary', 'Add new dictionary', '1');
INSERT INTO `cat_module_permission` VALUES(19, 10, 'add_dictionary_word', 'Add dictionary word', 'Add new pharagraph', '1');
INSERT INTO `cat_module_permission` VALUES(20, 10, 'edit_dictionary', 'Edit dictionary', 'Edit dictionary', '1');
INSERT INTO `cat_module_permission` VALUES(21, 10, 'edit_dictionary_word', 'Edit dictionary word', 'Edit paragraph', '1');
INSERT INTO `cat_module_permission` VALUES(22, 5, 'add_module_permission', 'Add module permission', 'Add new permissions', '1');
INSERT INTO `cat_module_permission` VALUES(23, 5, 'edit_module_permission', 'Edit module permission', 'Edit permission', '1');
INSERT INTO `cat_module_permission` VALUES(24, 5, 'edit_module', 'Edit module', 'Edit module', '1');
INSERT INTO `cat_module_permission` VALUES(25, 5, 'inactive_module', 'Inactive module', '', '1');
INSERT INTO `cat_module_permission` VALUES(26, 10, 'delete_dictionary', 'Delete dictionary', '', '1');
INSERT INTO `cat_module_permission` VALUES(27, 12, 'view_stock', 'View stock', '', '1');
INSERT INTO `cat_module_permission` VALUES(28, 12, 'edit_stock', 'Edit stock', '', '1');
INSERT INTO `cat_module_permission` VALUES(29, 12, 'delete_stock', 'Delete stock', '', '1');
INSERT INTO `cat_module_permission` VALUES(30, 12, 'add_item_in_stock', 'Add item in stock', '', '1');
INSERT INTO `cat_module_permission` VALUES(31, 12, 'add_stock', 'Add stock', '', '1');
INSERT INTO `cat_module_permission` VALUES(32, 12, 'add_stock_item', 'Add stock item', 'Add new items for stock', '1');
INSERT INTO `cat_module_permission` VALUES(33, 12, 'inactive_stock', 'Inactive stock', '', '1');
INSERT INTO `cat_module_permission` VALUES(34, 13, 'add_provider', 'Add provider', '', '1');
INSERT INTO `cat_module_permission` VALUES(35, 2, 'edit_rol', 'Edit rol', 'Edit rol per user', '1');
INSERT INTO `cat_module_permission` VALUES(36, 1, 'add_user_rol', 'Add user rol', 'Add roles for user', '1');
INSERT INTO `cat_module_permission` VALUES(37, 1, 'add_admin_user', 'Add admin user', 'Add new user rol with admin account', '1');
INSERT INTO `cat_module_permission` VALUES(38, 14, 'edit_user_setting', 'Edit user setting', 'Edit user settings', '1');
INSERT INTO `cat_module_permission` VALUES(39, 10, 'delete_dictionary_word', 'Delete dictionary word', 'Delete lines in dictionary', '1');
INSERT INTO `cat_module_permission` VALUES(40, 15, 'view_products', 'View products', '', '1');
INSERT INTO `cat_module_permission` VALUES(41, 15, 'edit_product', 'Edit product', '', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_number_format`
--

CREATE TABLE `cat_number_format` (
  `cat_number_format_id` int(11) NOT NULL AUTO_INCREMENT,
  `number_format` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_number_format_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2147483647 ;

--
-- Volcar la base de datos para la tabla `cat_number_format`
--

INSERT INTO `cat_number_format` VALUES(1, '1,000.00', '1');
INSERT INTO `cat_number_format` VALUES(2, '1000.00', '1');
INSERT INTO `cat_number_format` VALUES(3, '1 000,00', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_time_zone`
--

CREATE TABLE `cat_time_zone` (
  `cat_time_zone_id` int(11) NOT NULL AUTO_INCREMENT,
  `time_zone` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci DEFAULT '1',
  PRIMARY KEY (`cat_time_zone_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2147483647 ;

--
-- Volcar la base de datos para la tabla `cat_time_zone`
--

INSERT INTO `cat_time_zone` VALUES(1, 'America/Mexico_city', '1');
INSERT INTO `cat_time_zone` VALUES(2, 'America/Tijuana', '1');
INSERT INTO `cat_time_zone` VALUES(3, 'America/Mazatlan', '1');
INSERT INTO `cat_time_zone` VALUES(4, 'America/Los Angeles', '1');
INSERT INTO `cat_time_zone` VALUES(5, 'America/Monterrey', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_user_rol`
--

CREATE TABLE `cat_user_rol` (
  `cat_user_rol_id` int(11) NOT NULL AUTO_INCREMENT,
  `rol` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_user_rol_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `cat_user_rol`
--

INSERT INTO `cat_user_rol` VALUES(1, 'Admin', 'User admin in the system. He have all privilegies', '1');
INSERT INTO `cat_user_rol` VALUES(2, 'User', 'User in the system. his privileges depend to administrator', '1');
INSERT INTO `cat_user_rol` VALUES(3, 'Member', 'User members in the company. Not have privilegies', '1');
INSERT INTO `cat_user_rol` VALUES(4, 'Manager', '', '0');
INSERT INTO `cat_user_rol` VALUES(5, 'Adviser', '', '0');
INSERT INTO `cat_user_rol` VALUES(6, 'Doctor', '', '0');
INSERT INTO `cat_user_rol` VALUES(7, 'Seller', '', '0');
INSERT INTO `cat_user_rol` VALUES(8, 'Provider', '', '1');
INSERT INTO `cat_user_rol` VALUES(9, 'Instructor', 'User with account instructor privileges. \r\n\r\nFor create teams and assign routines, etc.', '1');
INSERT INTO `cat_user_rol` VALUES(10, 'Client', '', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cat_user_x_rol`
--

CREATE TABLE `cat_user_x_rol` (
  `cat_user_x_rol_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_user_rol_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`cat_user_x_rol_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=17 ;

--
-- Volcar la base de datos para la tabla `cat_user_x_rol`
--

INSERT INTO `cat_user_x_rol` VALUES(1, 1, 1, '1');
INSERT INTO `cat_user_x_rol` VALUES(2, 2, 1, '1');
INSERT INTO `cat_user_x_rol` VALUES(3, 2, 2, '1');
INSERT INTO `cat_user_x_rol` VALUES(4, 3, 1, '0');
INSERT INTO `cat_user_x_rol` VALUES(5, 4, 1, '1');
INSERT INTO `cat_user_x_rol` VALUES(6, 5, 1, '1');
INSERT INTO `cat_user_x_rol` VALUES(7, 6, 1, '0');
INSERT INTO `cat_user_x_rol` VALUES(8, 7, 1, '1');
INSERT INTO `cat_user_x_rol` VALUES(9, 8, 1, '0');
INSERT INTO `cat_user_x_rol` VALUES(10, 9, 1, '0');
INSERT INTO `cat_user_x_rol` VALUES(11, 3, 3, '1');
INSERT INTO `cat_user_x_rol` VALUES(12, 3, 4, '1');
INSERT INTO `cat_user_x_rol` VALUES(13, 3, 5, '1');
INSERT INTO `cat_user_x_rol` VALUES(14, 3, 6, '1');
INSERT INTO `cat_user_x_rol` VALUES(15, 3, 7, '1');
INSERT INTO `cat_user_x_rol` VALUES(16, 2, 7, '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `image`
--

CREATE TABLE `image` (
  `image_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_image_id` int(11) NOT NULL,
  `title` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `detail` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`image_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=11 ;

--
-- Volcar la base de datos para la tabla `image`
--

INSERT INTO `image` VALUES(1, 3, 'Arka 1', '/apps/admin/subcore/media/images/1.jpg', 'Detalles de la imagen 1', '573681997', '1');
INSERT INTO `image` VALUES(2, 3, 'Arka 2', '/apps/admin/subcore/media/images/2.jpg', 'Detalles para la imagen dos', '573681997', '1');
INSERT INTO `image` VALUES(3, 3, 'Arka 3', '/apps/admin/subcore/media/images/3.jpg', 'Detalles de la imagen 3', '573681997', '1');
INSERT INTO `image` VALUES(4, 3, 'Arka 4', '/apps/admin/subcore/media/images/4.jpg', 'Detalles para la imagen 4', '573681997', '1');
INSERT INTO `image` VALUES(5, 3, 'Arka 5', '/apps/admin/subcore/media/images/5.jpg', 'Detalles de la imagen 5', '573681997', '1');
INSERT INTO `image` VALUES(6, 3, 'Arka 6', '/apps/admin/subcore/media/images/6.jpg', 'Detalles para la imagen 6', '573681997', '1');
INSERT INTO `image` VALUES(7, 3, 'Arka 7', '/apps/admin/subcore/media/images/7.jpg', 'Detalles de la imagen 7', '573681997', '1');
INSERT INTO `image` VALUES(8, 3, 'Arka 8', '/apps/admin/subcore/media/images/8.jpg', 'Detalles de la imagen 8', '573681997', '1');
INSERT INTO `image` VALUES(9, 3, 'Arka 9', '/apps/admin/subcore/media/images/9.jpg', 'Detalles de la imagen 9', '573681997', '1');
INSERT INTO `image` VALUES(10, 3, 'Arka 10', '/apps/admin/subcore/media/images/10.jpg', 'Detalles de la imagen 10', '573681997', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `image_galery`
--

CREATE TABLE `image_galery` (
  `image_galery_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `title` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `image` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`image_galery_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `image_galery`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sys_counter`
--

CREATE TABLE `sys_counter` (
  `sys_counter_id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`sys_counter_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `sys_counter`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sys_tracking`
--

CREATE TABLE `sys_tracking` (
  `sys_tracking_id` int(11) NOT NULL AUTO_INCREMENT,
  `action_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `who_id` int(11) NOT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `detail` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`sys_tracking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `sys_tracking`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_login_id` int(11) NOT NULL,
  `names` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `mother_name` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `rfc` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `curp` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `birthday` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `sex` enum('man','woman') COLLATE utf8_unicode_ci NOT NULL DEFAULT 'man',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `user`
--

INSERT INTO `user` VALUES(1, 1, 'Admin', 'System', 'Support', 'SYSA 850418', '', '482702069', 'man');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_account`
--

CREATE TABLE `user_account` (
  `user_account_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_sponsor_id` int(11) NOT NULL,
  `cat_plan_id` int(11) NOT NULL,
  `membership` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `start_date` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `contract_date` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `expiration_date` varchar(45) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`user_account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `user_account`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_address`
--

CREATE TABLE `user_address` (
  `user_address_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `city_id` int(11) NOT NULL,
  `sector_id` int(11) NOT NULL,
  `cat_address_id` int(11) NOT NULL DEFAULT '1',
  `street` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `number` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `colony` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `postal_zip` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `place` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `interior` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `address_detail` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `address_cross` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `delete` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `user_address`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_billing`
--

CREATE TABLE `user_billing` (
  `user_billing_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `cat_card_id` int(11) NOT NULL,
  `card_number` int(11) NOT NULL,
  `code` int(11) NOT NULL,
  `holder_name` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `month` varchar(2) COLLATE utf8_unicode_ci NOT NULL,
  `year` varchar(4) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_billing_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `user_billing`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_contact`
--

CREATE TABLE `user_contact` (
  `user_contact_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `sys_contact_id` int(11) NOT NULL,
  `contact` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `custom` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `date` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `key` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `delete` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_contact_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `user_contact`
--


-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_login`
--

CREATE TABLE `user_login` (
  `user_login_id` int(11) NOT NULL AUTO_INCREMENT,
  `mail` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(99) COLLATE utf8_unicode_ci NOT NULL,
  `secret` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_login_date` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `delete` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Volcar la base de datos para la tabla `user_login`
--

INSERT INTO `user_login` VALUES(1, 'admin@spiderframe.com', '81dc9bdb52d04dc20036dbd8313ed055', '', '1388519669', '1', '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_permission`
--

CREATE TABLE `user_permission` (
  `user_permission_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_login_id` int(11) NOT NULL,
  `cat_module_permission_id` int(11) NOT NULL,
  `active` enum('0','1') COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  PRIMARY KEY (`user_permission_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=39 ;

--
-- Volcar la base de datos para la tabla `user_permission`
--

INSERT INTO `user_permission` VALUES(1, 1, 6, '1');
INSERT INTO `user_permission` VALUES(2, 1, 14, '1');
INSERT INTO `user_permission` VALUES(3, 1, 7, '1');
INSERT INTO `user_permission` VALUES(4, 1, 5, '1');
INSERT INTO `user_permission` VALUES(5, 1, 4, '1');
INSERT INTO `user_permission` VALUES(6, 1, 3, '1');
INSERT INTO `user_permission` VALUES(7, 1, 2, '1');
INSERT INTO `user_permission` VALUES(8, 1, 1, '1');
INSERT INTO `user_permission` VALUES(9, 1, 25, '1');
INSERT INTO `user_permission` VALUES(10, 1, 8, '1');
INSERT INTO `user_permission` VALUES(11, 1, 17, '1');
INSERT INTO `user_permission` VALUES(12, 1, 22, '1');
INSERT INTO `user_permission` VALUES(13, 1, 23, '1');
INSERT INTO `user_permission` VALUES(14, 1, 24, '1');
INSERT INTO `user_permission` VALUES(15, 1, 9, '1');
INSERT INTO `user_permission` VALUES(16, 1, 10, '1');
INSERT INTO `user_permission` VALUES(17, 1, 15, '1');
INSERT INTO `user_permission` VALUES(18, 1, 16, '1');
INSERT INTO `user_permission` VALUES(19, 1, 27, '1');
INSERT INTO `user_permission` VALUES(20, 1, 28, '1');
INSERT INTO `user_permission` VALUES(21, 1, 29, '1');
INSERT INTO `user_permission` VALUES(22, 1, 30, '1');
INSERT INTO `user_permission` VALUES(23, 1, 31, '1');
INSERT INTO `user_permission` VALUES(24, 1, 32, '1');
INSERT INTO `user_permission` VALUES(25, 1, 33, '1');
INSERT INTO `user_permission` VALUES(26, 1, 11, '1');
INSERT INTO `user_permission` VALUES(27, 1, 12, '1');
INSERT INTO `user_permission` VALUES(28, 1, 13, '1');
INSERT INTO `user_permission` VALUES(29, 1, 18, '1');
INSERT INTO `user_permission` VALUES(30, 1, 19, '1');
INSERT INTO `user_permission` VALUES(31, 1, 20, '1');
INSERT INTO `user_permission` VALUES(32, 1, 21, '1');
INSERT INTO `user_permission` VALUES(33, 1, 26, '1');
INSERT INTO `user_permission` VALUES(34, 1, 34, '1');
INSERT INTO `user_permission` VALUES(35, 1, 35, '1');
INSERT INTO `user_permission` VALUES(36, 1, 39, '1');
INSERT INTO `user_permission` VALUES(37, 1, 40, '1');
INSERT INTO `user_permission` VALUES(38, 1, 41, '1');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user_setting`
--

CREATE TABLE `user_setting` (
  `user_setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_login_id` int(11) NOT NULL,
  `cat_time_zone_id` int(11) NOT NULL,
  `cat_date_format_id` int(11) NOT NULL,
  `cat_number_format_id` int(11) NOT NULL,
  `language` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`user_setting_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

--
-- Volcar la base de datos para la tabla `user_setting`
